from distutils.core import setup

setup(
    name='disruption_analysis',
    version='0.5',
    packages=['analyses', 'pipelines', 'disruption', 'correlations', 'data_process'],
    url='""',
    license='technion',
    author='BennyP',
    author_email='sbp67250@campus.technion.ac.il',
    description=''
)
