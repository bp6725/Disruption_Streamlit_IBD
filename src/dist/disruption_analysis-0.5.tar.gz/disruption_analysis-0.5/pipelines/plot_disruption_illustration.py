from correlations.correlations_api import CorrelationsAPI
from data_process.data_api import DataAPI
import pandas as pd
from analyses.analyses_api import AnalysesApi
from disruption.disruption_analysis import DisruptionAnalysis
import seaborn as sns
from IPython.display import display
import matplotlib.pyplot as plt
import plotly.graph_objects as go

class PlotDisruptionIllustration():
    def __init__(self,feature_trhs=[0.1,0.3,-0.1,-0.3],diet_combinations = [(0,1),(1,0),(0,2),(2,0)],stage_for_disruption_prediction = "Before_MED",
                 corrected_pval_for_prediction = 0.25,disruption_analysis = None,corr_api = None,data_api = None,analyses_api = None):
        self.feature_trhs=feature_trhs
        self.diet_combinations = diet_combinations
        self.stage_for_disruption_prediction = stage_for_disruption_prediction
        self.corrected_pval_for_prediction = corrected_pval_for_prediction

        if disruption_analysis is None :
            self.disruption_analysis = DisruptionAnalysis()

        if corr_api is None :
            self.corr_api = CorrelationsAPI(self.disruption_analysis.alpah_fdr, self.disruption_analysis.corr_th)

        if data_api is None :
            self.data_api = DataAPI()

        if analyses_api is None :
            self.analyses_api = AnalysesApi()

    #region ploting tools

    def _genSankey(self, df, cat_cols=[], value_cols='', title='Sankey Diagram'):
        # maximum of 6 value cols -> 6 colors
        colorPalette = ['#4B8BBE', '#306998', '#FFE873', '#FFD43B', '#646464']
        labelList = []
        colorNumList = []
        for catCol in cat_cols:
            labelListTemp = list(set(df[catCol].values))
            colorNumList.append(len(labelListTemp))
            labelList = labelList + labelListTemp

        # remove duplicates from labelList
        labelList = list(dict.fromkeys(labelList))

        # define colors based on number of levels
        colorList = []
        for idx, colorNum in enumerate(colorNumList):
            colorList = colorList + [colorPalette[idx]] * colorNum

        # transform df into a source-target pair
        for i in range(len(cat_cols) - 1):
            if i == 0:
                sourceTargetDf = df[[cat_cols[i], cat_cols[i + 1], value_cols]]
                sourceTargetDf.columns = ['source', 'target', 'count']
            else:
                tempDf = df[[cat_cols[i], cat_cols[i + 1], value_cols]]
                tempDf.columns = ['source', 'target', 'count']
                sourceTargetDf = pd.concat([sourceTargetDf, tempDf])
            sourceTargetDf = sourceTargetDf.groupby(['source', 'target']).agg({'count': 'sum'}).reset_index()

        # add index for source-target pair
        sourceTargetDf['sourceID'] = sourceTargetDf['source'].apply(lambda x: labelList.index(x))
        sourceTargetDf['targetID'] = sourceTargetDf['target'].apply(lambda x: labelList.index(x))

        # creating the sankey diagram
        data = dict(
            type='sankey',
            node=dict(
                pad=15,
                thickness=20,
                line=dict(
                    color="black",
                    width=0.5
                ),
                label=labelList,
                color=colorList
            ),
            link=dict(
                source=sourceTargetDf['sourceID'],
                target=sourceTargetDf['targetID'],
                value=sourceTargetDf['count']
            )
        )

        layout = dict(
            title=title,
            font=dict(
                size=10
            )
        )

        fig = dict(data=[data], layout=layout)
        return fig

    def _plot_correlation(self, chosen_idx, _df, _df_for_regline, to_color, title, color_tag):
        _x = str(chosen_idx[0])
        _y = str(chosen_idx[1])

        x = _df[chosen_idx[0]]
        y = _df[chosen_idx[1]]

        h = pd.Series(data=f"non-{color_tag}", index=_df.index)

        h.loc[to_color] = color_tag

        _data = pd.DataFrame({_x: x, _y: y, "dis": h})

        #     sns.regplot(x=_x, y=_y, data=_data,ax=ax)

        if (len(_df.index) > len(_df.index.unique())):
            new_data = pd.DataFrame(index=(_data.index).unique(), columns=_data.columns)

            new_data[_x] = _data.groupby(level=0).mean()[_x]
            new_data[_y] = _data.groupby(level=0).mean()[_y]
            new_data["dis"] = _data.groupby(level=0)["dis"].first()

            _data = new_data.copy(deep=True)

        if color_tag == "disruptor":
            #         graph = sns.lmplot(x=_x, y=_y, hue='dis', data=_data, fit_reg=False)
            graph = sns.lmplot(x=_x, y=_y, hue='dis', palette=['purple', 'yellow'], data=_data, fit_reg=False)
        else:
            graph = sns.lmplot(x=_x, y=_y, hue='dis', data=_data, fit_reg=False)

        x_for_rl = _df_for_regline[chosen_idx[0]]
        y_for_rl = _df_for_regline[chosen_idx[1]]

        h_for_rl = pd.Series(data=f"non-{color_tag}", index=_df_for_regline.index)

        _data_for_rl = pd.DataFrame({_x: x_for_rl, _y: y_for_rl, "dis": h_for_rl})

        sns.regplot(x=_x, y=_y, data=_data_for_rl, scatter=False, ax=graph.axes[0, 0])
        graph.fig.suptitle(title)

    def _illustrate_disruption(self, relevent_correlations, seg_disruption_df, pn_in_corr, ref_z_disruption, z_dis_net,
                               diet_df, backbone_df, melted_corr_and_disruption, seg_imp_data, feature_trh,
                               is_creation_correlation=False):
        disruption_cutoff = 0.05
        predictions = melted_corr_and_disruption[melted_corr_and_disruption["corrected_pval"] < 0.25]
        for idx in range(seg_disruption_df.shape[0]):

            chosen_idx = seg_disruption_df.index[idx]

            print(f"------{chosen_idx}------")

            if not ((61587 in chosen_idx) and (35879 in chosen_idx) or (61587 in chosen_idx) and (
                    35879 in chosen_idx) or (61857 in chosen_idx) and (54890 in chosen_idx) or (
                            61857 in chosen_idx) and (32398 in chosen_idx) or (61857 in chosen_idx) and (
                            62374 in chosen_idx) or (62798 in chosen_idx) and (36600 in chosen_idx) or (
                            62798 in chosen_idx) and (48733 in chosen_idx) or (40007 in chosen_idx) and (
                            38102 in chosen_idx) or (40007 in chosen_idx) and (52608 in chosen_idx) or (
                            40007 in chosen_idx) and (62746 in chosen_idx) or (40007 in chosen_idx) and (
                            62746 in chosen_idx) or (62746 in chosen_idx) and (38102 in chosen_idx) or (
                            62746 in chosen_idx) and (52608 in chosen_idx) or (1561 in chosen_idx) and (
                            33418 in chosen_idx) or (1561 in chosen_idx) and (33418 in chosen_idx) or (
                            33418 in chosen_idx) and (52473 in chosen_idx) or (33418 in chosen_idx) and (
                            52473 in chosen_idx) or (47666 in chosen_idx) and (44876 in chosen_idx) or (
                            47666 in chosen_idx) and (62280 in chosen_idx) or (47666 in chosen_idx) and (
                            62280 in chosen_idx) or (15747 in chosen_idx) and (43256 in chosen_idx) or (
                            38652 in chosen_idx) and (43256 in chosen_idx) or (38652 in chosen_idx) and (
                            57651 in chosen_idx) or (57513 in chosen_idx) and (57651 in chosen_idx) or (
                            57635 in chosen_idx) and (57804 in chosen_idx) or (57637 in chosen_idx) and (
                            57651 in chosen_idx) or (1105 in chosen_idx) and (33447 in chosen_idx) or (
                            1105 in chosen_idx) and (34035 in chosen_idx) or (1105 in chosen_idx) and (
                            21232 in chosen_idx) or (1105 in chosen_idx) and (32506 in chosen_idx) or (
                            1105 in chosen_idx) and (32506 in chosen_idx) or (1105 in chosen_idx) and (
                            33587 in chosen_idx) or (1105 in chosen_idx) and (33971 in chosen_idx) or (
                            1105 in chosen_idx) and (54920 in chosen_idx) or (32980 in chosen_idx) and (
                            32415 in chosen_idx) or (32980 in chosen_idx) and (57443 in chosen_idx) or (
                            32980 in chosen_idx) and ("Calprotectin" in chosen_idx) or (32980 in chosen_idx) and (
                            47123 in chosen_idx) or (32415 in chosen_idx) and (15747 in chosen_idx) or (
                            32415 in chosen_idx) and (33587 in chosen_idx) or (32415 in chosen_idx) and (
                            33968 in chosen_idx) or (32415 in chosen_idx) and (44877 in chosen_idx) or (
                            44877 in chosen_idx) and (57432 in chosen_idx) or (44877 in chosen_idx) and (
                            57517 in chosen_idx) or (44877 in chosen_idx) and (57517 in chosen_idx) or (
                            57432 in chosen_idx) and (57517 in chosen_idx) or (57432 in chosen_idx) and (
                            57525 in chosen_idx)):
                continue

            ref_dist = ref_z_disruption.loc[chosen_idx]
            diet_dist = z_dis_net.loc[chosen_idx]
            disruption_values = z_dis_net.loc[chosen_idx]

            _pn_in_corr = pn_in_corr.loc[chosen_idx][pn_in_corr.loc[chosen_idx]].index.to_list()

            disruption_values[disruption_values.index.difference(pd.Index(_pn_in_corr))] = 0
            positive_disrupted = disruption_values[disruption_values > 0].index.to_list()

            # disrupted pn relevent to disruption score - clean_disruption_df
            _clean_disruption = seg_disruption_df.loc[chosen_idx].copy(deep=True)
            disrupted_pn = _clean_disruption[_clean_disruption >= disruption_cutoff].index.to_list()
            non_disrupted_pn = self.intersection(_clean_disruption[_clean_disruption < disruption_cutoff].index.to_list(),
                                            _pn_in_corr)

            #         if True :
            try:
                is_created_str = "created" if is_creation_correlation else ""
                self._plot_correlation(chosen_idx, backbone_df.rank(), backbone_df.rank(), _pn_in_corr,
                                 f"reference rank {is_created_str}", "contributors")
                self._plot_correlation(chosen_idx, self.diet_rank_in_refrence(diet_df.copy(deep=True), backbone_df.copy(deep=True),
                                                                              _pn_in_corr), backbone_df.rank(), positive_disrupted,
                                 f"diet rank {is_created_str}", "disruptor")


                #             plot_net_with_dis_edge(relevent_correlations,chosen_idx)
                #             plot_net_with_dis_nodes(diet_corr,chosen_idx)
                plt.show()

                #           dist plot:
                kwargs = dict(hist_kws={'alpha': .6}, kde_kws={'linewidth': 2, 'bw': 0.15})
                plt.figure(figsize=(10, 7), dpi=80)
                sns.distplot(diet_df["CRP_delta"].loc[disrupted_pn].dropna(), color="dodgerblue", label="disrupted pn",
                             **kwargs)
                sns.distplot(diet_df["CRP_delta"].loc[~diet_df.index.isin(disrupted_pn)].dropna(), color="orange",
                             label="non disrupted pn", **kwargs)
                plt.legend();
                plt.show()

                plt.figure(figsize=(10, 7), dpi=80)
                sns.distplot(diet_df["CRP_delta"].loc[set(disrupted_pn).intersection(_pn_in_corr)].dropna(), hist=False,
                             color="purple", label="disrupted pn", **kwargs)
                sns.distplot(diet_df["CRP_delta"].loc[set(non_disrupted_pn).intersection(_pn_in_corr)].dropna(),
                             hist=False, color="yellow", label="non disrupted pn", **kwargs)
                plt.legend();
                plt.show()

                #             fig, ax = plt.subplots()

                #             rel_dis = disruption_values[disruption_values>0].sort_values(ascending = True)
                #             ax.barh(rel_dis.index, rel_dis, align='center')
                #             ax.set_xlabel('disruption values')
                #             plt.show()

                if feature_trh >= 0:
                    pn_over_crp = diet_df["CRP_delta"][diet_df["CRP_delta"] >= feature_trh].index
                else:
                    pn_over_crp = diet_df["CRP_delta"][diet_df["CRP_delta"] <= feature_trh].index

                # sankey plot
                all_pns = set(diet_df.index.to_list())

                n_pn_in_corr = pd.Index(_pn_in_corr)

                disrupted = len(set(disrupted_pn))
                not_disrupted = len(set(non_disrupted_pn))

                reponders_not_in_corr = len(self.intersection(self.Diff(n_pn_in_corr.to_list(), all_pns), pn_over_crp.to_list()))
                not_in_corr_not_responders = len(
                    self.intersection(self.Diff(n_pn_in_corr.to_list(), all_pns), self.Diff(pn_over_crp.to_list(), all_pns)))

                disrupted_responders = len(self.intersection(disrupted_pn, pn_over_crp.to_list()))
                disrupted_non_responders = len(self.intersection(disrupted_pn, self.Diff(pn_over_crp.to_list(), all_pns)))

                not_disrupted_responders = len(self.intersection(non_disrupted_pn, pn_over_crp.to_list()))
                not_disrupted_not_responders = len(self.intersection(non_disrupted_pn, self.Diff(pn_over_crp.to_list(), all_pns)))

                print(f"disrupted_pn : {disrupted_pn}")
                print(f"non_disrupted_pn : {non_disrupted_pn}")
                print(f"n_pn_in_corr : {n_pn_in_corr}")
                print(f"not n_pn_in_corr : {self.Diff(n_pn_in_corr.to_list(), all_pns)}")
                print(f"incresed : {pn_over_crp}")
                print(f"decresed : {self.Diff(pn_over_crp.to_list(), all_pns)}")

                if (disrupted + not_disrupted) != len(n_pn_in_corr):
                    display(seg_disruption_df.loc[chosen_idx])
                    display(_pn_in_corr)

                labels_dielation = ["contributors to ref corr", "non contributors to ref corr", "disrupted patients",
                                    "non disrupted patients", "increased CRP", "decreased CRP"]
                labels_creation = ["contributors to diet corr", "non contributors to diet corr", "wasnt in corr in ref",
                                   "was in corr in ref", "increased CRP", "decreased CRP"]

                fig = go.Figure(data=[go.Sankey(
                    node=dict(
                        pad=15,
                        thickness=20,
                        line=dict(color="black", width=0.5),
                        label=["correlation contributors", "not in correlation", "disrupted patients",
                               "non disrupted patients", "increased CRP", "decreased CRP"],
                        color=['orange', "blue", 'purple', 'yellow', 'red', 'green']
                    ),
                    link=dict(
                        source=[0, 0, 1, 1, 2, 2, 3, 3],
                        target=[2, 3, 4, 5, 4, 5, 4, 5],
                        value=[disrupted, not_disrupted, reponders_not_in_corr, not_in_corr_not_responders,
                               disrupted_responders, disrupted_non_responders, not_disrupted_responders,
                               not_disrupted_not_responders]
                    ))])

                fig.update_layout(title_text="Basic Sankey Diagram", font_size=15)
                fig.show()

                corr_str = f"{chosen_idx[0]}-{chosen_idx[1]}"
                try:
                    if corr_str in predictions.index.get_level_values(0):
                        #             predictions
                        rel_dis = disruption_values[_pn_in_corr].sort_values(ascending=True)
                        predictor = predictions.loc[corr_str].idxmin()["corrected_pval"]
                        mat = seg_imp_data[predictor].loc[rel_dis.index]

                        fig, axes = plt.subplots(ncols=2, sharey=True)
                        axes[0].barh(rel_dis.index, rel_dis, align='center')
                        axes[0].set_xlabel('disruption score')
                        axes[1].barh(mat.index, mat, align='center')
                        axes[1].set_xlabel(predictor)
                        axes[0].invert_xaxis()
                        fig.suptitle("disruption score vs metabolism at reference")
                        plt.show()
                except:
                    print("hello")
            except Exception as  e:
                #             print(disrupted_pn)
                #             print(disruption_values)
                print(f"error : {e}")
                display(diet_df["CRP_delta"])

    #endregion

    #region tools

    def is_in_list_of_disruptions(self,idx, list_of_disruptions):
        return any([((str(lod[0]) == str(idx[0])) and (str(lod[1]) == str(idx[1]))) or (
                    (str(lod[0]) == str(idx[1])) and (str(lod[1]) == str(idx[0]))) for lod in list_of_disruptions])

    def Diff(self,li1, li2):
        return (list(list(set(li1) - set(li2)) + list(set(li2) - set(li1))))

    def intersection(self,lst1, lst2):
        return list(set(lst1) & set(lst2))

    def cast_to_int(self,st):
        if (st.isdigit()):
            return int(st)
        return st

    def diet_rank_in_refrence(self,diet_df, backbone_df, _pn_in_corr):
        _added_df = diet_df.copy(deep=True)
        value_of_diet_in_backbone = pd.DataFrame(columns=backbone_df.columns)

        for pn in _pn_in_corr:
            _pn_dis = f"{pn}_dis"
            _ref_df = backbone_df.copy(deep=True)
            if type(_added_df.loc[pn]) is pd.Series:
                new_line = pd.Series(index=_added_df.loc[pn].index, data=_added_df.loc[pn], name=_pn_dis)
                new_ref_df = _ref_df.append(new_line)
            else:
                new_df = _added_df.loc[pn].copy(deep=True)
                new_df.index = new_df.index.map(lambda x: _pn_dis)
                new_ref_df = _ref_df.append(new_df)

            value_of_diet_in_backbone = value_of_diet_in_backbone.append(new_ref_df.rank().loc[_pn_dis])

        value_of_diet_in_backbone.index = value_of_diet_in_backbone.index.map(lambda x: x.split("_")[0])
        return value_of_diet_in_backbone

    #endregion

    def illustrate_all_permutation(self):
        for diet_index, backbone_index in self.diet_combinations :
            self.disruption_analysis.update_class_properties({"reference_diet_idx": backbone_index ,"treatment_diet_idx" : diet_index})

            relevent_correlations = self.corr_api.return_correlation_by_index(self.disruption_analysis.reference_diet_idx)
            ref_z_disruption = self.disruption_analysis.calculate_ref_z_disruption()
            z_dis_net = self.disruption_analysis.calculate_z_disruption_networks()
            clean_disruption_df = self.disruption_analysis.get_disruption_score()
            pn_in_corr = self.disruption_analysis.get_patient_in_correlation()

            diet_df = self.disruption_analysis.get_diet_df_with_delta()
            backbone_df = self.data_api.return_unagg_by_index(backbone_index)

            for feature_trh in self.feature_trhs:
                list_melted_corr_and_disruption = []
                for i in range(3):
                    # only disruption of sig features - same indexes as enriched_features_df. its only for reshapeing the df
                    enriched_features_df = self.disruption_analysis.get_enriched_features(feature_trh, only_pre_picked_features = True)
                    disruption_of_sig_modules = z_dis_net.loc[[v for v in enriched_features_df.values()][0].index]
                    disruption_of_sig_modules.index = disruption_of_sig_modules.index.map(lambda x: f"{x[0]}-{x[1]}")

                    if disruption_of_sig_modules.empty:
                        continue

                    sc_imp_data = self.data_api.return_relvent_sc_imp_data(stage=self.stage_for_disruption_prediction )
                    seg_imp_data = sc_imp_data[self.data_api.union_ref_df.columns.intersection(sc_imp_data.columns)]

                    melted_corr_and_disruption = self.analyses_api.calculate_joined_correlation_to_disruption(disruption_of_sig_modules, seg_imp_data, pn_in_corr)
                    if melted_corr_and_disruption is None :
                        continue

                    list_melted_corr_and_disruption.append(
                        melted_corr_and_disruption[melted_corr_and_disruption["corrected_pval"] < self.corrected_pval_for_prediction])

                if len(list_melted_corr_and_disruption) == 0:
                    continue

                all_melted_corr_and_disruption = pd.concat(list_melted_corr_and_disruption).drop_duplicates()
                all_melted_corr_and_disruption = all_melted_corr_and_disruption.copy(deep=True)

                list_of_disruptions = all_melted_corr_and_disruption.index.get_level_values(0).drop_duplicates().map(
                    lambda x: (str(self.cast_to_int(x.split("-")[0])), str(self.cast_to_int(x.split("-")[1])))).tolist()

                all_melted_corr_and_disruption.index = all_melted_corr_and_disruption.index.map(self.data_api.rename_index)

                seg_disruption_df = clean_disruption_df.loc[
                    clean_disruption_df.index.map(lambda x: self.is_in_list_of_disruptions(x, list_of_disruptions))]

                print("start illustrate")
                self._illustrate_disruption(relevent_correlations, seg_disruption_df, pn_in_corr, ref_z_disruption, z_dis_net, diet_df, backbone_df, melted_corr_and_disruption, seg_imp_data, 0, diet_index == 0)
